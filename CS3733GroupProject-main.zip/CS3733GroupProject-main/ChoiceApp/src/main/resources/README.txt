Placing here ONLY so git checks out this directory; otherwise if this were empty, git wouldn't check it out.
