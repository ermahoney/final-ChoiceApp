package com.amazonaws.lambda.demo.http;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestAddRequest {

	/*@Test
	public void test() {
		SignInRequest ar = new SignInRequest();
		ar.setChoiceID("3.1");
		assertEquals("3.1", ar.arg1);
		
		//ar.setUsername("3.2");
		assertEquals("3.2", ar.arg2);
		
		ar = new SignInRequest("3.1", "3.2");
		assertEquals("3.1", ar.arg1);
		assertEquals("3.2", ar.arg2);
	}*/
}
